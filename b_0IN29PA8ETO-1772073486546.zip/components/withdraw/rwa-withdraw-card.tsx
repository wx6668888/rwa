'use client'

import { useState, useEffect, useCallback } from 'react'
import { Clock, Loader2 } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

type WithdrawStatus = 'idle' | 'pending' | 'success' | 'error'
type CooldownState = 'ready' | 'cooling'

const COOLDOWN_TOTAL = 24 * 3600
const COOLDOWN_REMAINING = 18 * 3600 + 24 * 60 + 10 // 18:24:10

function formatCountdown(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':')
}

interface Props {
  onPendingChange: (pending: boolean, txHash?: string) => void
}

export function RwaWithdrawCard({ onPendingChange }: Props) {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  const [cooldown] = useState<CooldownState>('cooling')
  const [countdown, setCountdown] = useState(COOLDOWN_REMAINING)
  const [amount, setAmount] = useState('')
  const [status, setStatus] = useState<WithdrawStatus>('idle')
  const [showFee, setShowFee] = useState(false)

  // Countdown tick
  useEffect(() => {
    if (cooldown !== 'cooling') return
    const id = setInterval(() => setCountdown((s) => Math.max(0, s - 1)), 1000)
    return () => clearInterval(id)
  }, [cooldown])

  const numAmount = parseFloat(amount) || 0
  const feeAmount = numAmount * 0.05
  const receiveAmount = numAmount - feeAmount
  const usdValue = receiveAmount * 0.85

  useEffect(() => {
    const timer = setTimeout(() => setShowFee(numAmount > 0), 60)
    if (numAmount === 0) setShowFee(false)
    return () => clearTimeout(timer)
  }, [numAmount])

  const handleWithdraw = useCallback(() => {
    if (cooldown === 'cooling' || numAmount <= 0 || status === 'pending') return
    setStatus('pending')
    onPendingChange(true)
    setTimeout(() => {
      setStatus('success')
      onPendingChange(true, '0xAbc...def')
      setTimeout(() => {
        onPendingChange(false)
        setStatus('idle')
        setAmount('')
      }, 3000)
    }, 2500)
  }, [cooldown, numAmount, status, onPendingChange])

  const progressPct = Math.round(((COOLDOWN_TOTAL - countdown) / COOLDOWN_TOTAL) * 100)

  return (
    <div
      className="rounded-2xl border p-6"
      style={{
        background: '#0d0d14',
        borderColor: '#00f5d4',
        boxShadow: '0 0 0 1px #00f5d440, 0 8px 32px #00f5d415',
      }}
    >
      {/* Header row */}
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold text-[#f1f5f9]">{t('withdraw.rwaTitle')}</span>
        {cooldown === 'ready' ? (
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#10b981]" />
            <span className="text-xs font-medium text-[#10b981]">{t('withdraw.ready')}</span>
          </span>
        ) : (
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-[#fb923c]" />
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-sm font-medium text-[#fb923c]">
              {formatCountdown(countdown)}
            </span>
          </span>
        )}
      </div>

      {/* Balance display */}
      <div className="mt-4">
        <div className="flex items-baseline gap-2">
          <span className="font-[family-name:var(--font-jetbrains-mono)] text-[44px] font-bold leading-none text-[#f1f5f9]">
            1,245.67
          </span>
          <span className="font-[family-name:var(--font-jetbrains-mono)] text-xl font-semibold text-[#00f5d4]">
            RWA
          </span>
        </div>
        <p className="mt-1 font-[family-name:var(--font-jetbrains-mono)] text-sm text-[#64748b]">
          ≈ $1,058.73 USDT
        </p>
      </div>

      {/* Amount input */}
      <div className="mt-5">
        <div className="flex items-center justify-between">
          <span className="text-xs text-[#64748b]">{t('withdraw.amountLabel')}</span>
          <span className="font-[family-name:var(--font-jetbrains-mono)] text-xs text-[#64748b]">
            {t('withdraw.balance')}
          </span>
        </div>
        <div className="mt-2 flex h-16 items-center gap-3 rounded-xl border border-[#ffffff1a] bg-[#13131e] px-5 transition-colors focus-within:border-[#00f5d440]">
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="flex-1 bg-transparent font-[family-name:var(--font-jetbrains-mono)] text-2xl text-[#f1f5f9] outline-none placeholder:text-[#334155] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
            aria-label={t('withdraw.amountLabel')}
          />
          <div className="flex shrink-0 items-center gap-2">
            <span className="flex items-center gap-1.5 rounded-full border border-[#ffffff0d] bg-[#1a1a2e] px-3 py-1.5">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#00f5d4] text-[10px] font-bold text-[#05050a]">R</span>
              <span className="text-sm font-semibold text-[#f1f5f9]">RWA</span>
            </span>
            <button
              type="button"
              onClick={() => setAmount('1245.67')}
              className="rounded-full border border-[#00f5d440] px-3 py-1 text-xs font-semibold text-[#00f5d4] transition-colors hover:bg-[#00f5d410]"
            >
              {t('withdraw.max')}
            </button>
          </div>
        </div>
      </div>

      {/* Fee breakdown — animate in */}
      <div
        className="overflow-hidden transition-all duration-300 ease-out"
        style={{ maxHeight: showFee ? '200px' : '0', opacity: showFee ? 1 : 0 }}
      >
        <div className="mt-4 rounded-xl border border-[#ffffff0d] bg-[#13131e] p-4">
          <div className="space-y-1.5 font-[family-name:var(--font-jetbrains-mono)] text-[13px]">
            <div className="flex items-center justify-between">
              <span className="text-[#64748b]">{t('withdraw.feeRow')}</span>
              <span className="text-[#f1f5f9]">{numAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })} RWA</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#64748b]">{t('withdraw.feeCharge')}</span>
              <span className="text-[#f43f5e]">−{feeAmount.toFixed(2)} RWA</span>
            </div>
            <div className="my-2 h-px bg-[#ffffff0d]" />
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#f1f5f9]">{t('withdraw.youReceive')}</span>
              <span className="text-base font-bold text-[#00f5d4]">{receiveAmount.toFixed(2)} RWA</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#64748b]">{t('withdraw.usdEquiv')}</span>
              <span className="text-[#64748b]">≈ ${usdValue.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cooldown progress bar */}
      {cooldown === 'cooling' && (
        <div className="mt-4">
          <div className="flex items-center justify-between">
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-[11px] text-[#64748b]">
              {t('withdraw.cooldownLabel')}
            </span>
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-[11px] text-[#64748b]">
              {formatCountdown(countdown)}
            </span>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-[#1a1a2e]">
            <div
              className="h-full rounded-full bg-[#fb923c] transition-all duration-1000"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      )}

      {/* Withdraw button */}
      <button
        type="button"
        onClick={handleWithdraw}
        disabled={cooldown === 'cooling' || status === 'pending'}
        className="mt-5 flex h-14 w-full items-center justify-center rounded-full font-[family-name:var(--font-space-grotesk)] text-sm font-bold transition-all"
        style={
          cooldown === 'cooling'
            ? { background: '#13131e', color: '#334155', cursor: 'not-allowed' }
            : status === 'pending'
            ? { background: '#00f5d4cc', color: '#05050a', cursor: 'not-allowed' }
            : { background: '#00f5d4', color: '#05050a' }
        }
      >
        {status === 'pending' ? (
          <span className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            {t('withdraw.pending')}
          </span>
        ) : cooldown === 'cooling' ? (
          t('withdraw.cooling')
        ) : (
          t('withdraw.button')
        )}
      </button>
    </div>
  )
}
