'use client'

import { useState, useCallback } from 'react'
import { Info } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'
import { RwaWithdrawCard } from '@/components/withdraw/rwa-withdraw-card'
import { UsdtRewardsCard } from '@/components/withdraw/usdt-rewards-card'
import { TxOverlay } from '@/components/withdraw/tx-overlay'

export function WithdrawPageClient() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  const [txPending, setTxPending] = useState(false)
  const [txHash, setTxHash] = useState<string | undefined>()

  const handlePendingChange = useCallback((pending: boolean, hash?: string) => {
    setTxPending(pending)
    setTxHash(hash)
  }, [])

  return (
    <>
      <main className="mx-auto max-w-[600px] px-4 pb-[100px] pt-10">
        {/* Page header */}
        <div className="mb-8">
          <p className="text-[11px] font-semibold uppercase tracking-widest text-[#64748b]">
            {t('withdraw.overline')}
          </p>
          <h1 className="mt-1 font-[family-name:var(--font-space-grotesk)] text-[32px] font-bold leading-tight text-[#f1f5f9]">
            {t('withdraw.title')}
          </h1>
        </div>

        {/* Card 1 — RWA withdrawal */}
        <RwaWithdrawCard onPendingChange={handlePendingChange} />

        {/* Card 2 — USDT rewards */}
        <UsdtRewardsCard />

        {/* Notice */}
        <div className="mt-4 flex items-start gap-2">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#00f5d4]" aria-hidden="true" />
          <p className="text-[13px] leading-relaxed text-[#64748b]">{t('withdraw.notice')}</p>
        </div>
      </main>

      {/* Transaction overlay */}
      <TxOverlay visible={txPending} txHash={txHash} />
    </>
  )
}
