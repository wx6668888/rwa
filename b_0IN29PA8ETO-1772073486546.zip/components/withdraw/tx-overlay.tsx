'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

interface Props {
  visible: boolean
  txHash?: string
}

export function TxOverlay({ visible, txHash }: Props) {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  if (!visible) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: '#05050acc', backdropFilter: 'blur(6px)' }}
      role="dialog"
      aria-modal="true"
      aria-label={t('withdraw.txTitle')}
    >
      <div
        className="flex w-80 flex-col items-center rounded-2xl border p-8 text-center"
        style={{ background: '#13131e', borderColor: '#ffffff1a' }}
      >
        {/* Spinner */}
        <div
          className="h-12 w-12 animate-spin rounded-full border-4"
          style={{ borderColor: '#1a1a2e', borderTopColor: '#00f5d4' }}
          aria-hidden="true"
        />

        <p className="mt-4 font-[family-name:var(--font-space-grotesk)] text-base font-semibold text-[#f1f5f9]">
          {t('withdraw.txTitle')}
        </p>
        <p className="mt-2 text-[13px] text-[#64748b]">{t('withdraw.txSubtitle')}</p>

        {txHash && (
          <div className="mt-3 flex items-center gap-2">
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-xs text-[#64748b]">
              {t('withdraw.txLabel')} {txHash}
            </span>
            <a
              href="#"
              className="text-xs font-medium text-[#00f5d4] transition-opacity hover:opacity-80"
              target="_blank"
              rel="noopener noreferrer"
            >
              {t('withdraw.viewBscscan')}
            </a>
          </div>
        )}
      </div>
    </div>
  )
}
