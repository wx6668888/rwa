'use client'

interface Props {
  t: (key: string) => string
}

export function ReturnCalculator({ t }: Props) {
  return (
    <div
      className="mt-4 border border-[#10b981] bg-[#0d0d14] p-6"
      style={{ borderRadius: '0.75rem' }}
    >
      <p
        className="text-[11px] uppercase tracking-widest text-[#64748b]"
        style={{ fontVariant: 'small-caps' }}
      >
        {t('emergency.calcTitle')}
      </p>

      <div className="mt-4 flex flex-col gap-3 font-mono text-[13px]">
        {/* Row: original staked */}
        <div className="flex items-center justify-between">
          <span className="text-[#64748b]">{t('emergency.calcStaked')}</span>
          <span className="text-[#f1f5f9]">1,000.00 USDT</span>
        </div>

        {/* Row: refundable 50% */}
        <div className="flex items-center justify-between">
          <span className="text-[#64748b]">{t('emergency.calcAvail')}</span>
          <span className="text-[#64748b]">500.00 USDT</span>
        </div>

        {/* Row: deducted USDT rewards */}
        <div className="flex items-center justify-between">
          <span className="text-[#64748b]">{t('emergency.calcDeduct')}</span>
          <span className="text-[#f43f5e]">−85.00 USDT</span>
        </div>

        {/* Divider */}
        <div className="my-1 h-px bg-[#ffffff0d]" />

        {/* Row: you receive */}
        <div className="flex items-end justify-between">
          <span className="text-sm font-bold text-[#f1f5f9]">
            {t('emergency.youReceive')}
          </span>
          <span
            className="text-[28px] font-bold leading-none text-[#10b981]"
            style={{ fontFamily: 'var(--font-mono)' }}
          >
            415.00 USDT
          </span>
        </div>
      </div>

      <p className="mt-3 text-[11px] text-[#64748b]">{t('emergency.calcNote')}</p>
    </div>
  )
}
