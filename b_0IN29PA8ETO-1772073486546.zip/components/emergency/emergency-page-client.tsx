'use client'

import { useState } from 'react'
import { AlertTriangle } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'
import { WarningCards } from '@/components/emergency/warning-cards'
import { ReturnCalculator } from '@/components/emergency/return-calculator'
import { ConfirmationSequence } from '@/components/emergency/confirmation-sequence'
import { EmergencyButton } from '@/components/emergency/emergency-button'
import { FaqAccordion } from '@/components/emergency/faq-accordion'

type BtnState = 'disabled' | 'enabled' | 'pending'

export function EmergencyPageClient() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  const [check1, setCheck1] = useState(false)
  const [check2, setCheck2] = useState(false)
  const [confirmValue, setConfirmValue] = useState('')
  const [btnState, setBtnState] = useState<BtnState>('disabled')

  const confirmWord = t('emergency.confirmWord')
  const allDone = check1 && check2 && confirmValue === confirmWord

  // Keep button state in sync with form state
  function computeState(): BtnState {
    if (btnState === 'pending') return 'pending'
    return allDone ? 'enabled' : 'disabled'
  }

  function handleWithdraw() {
    if (!allDone) return
    setBtnState('pending')
    // Simulate TX — reset after 3s
    setTimeout(() => {
      setBtnState('disabled')
      setCheck1(false)
      setCheck2(false)
      setConfirmValue('')
    }, 3000)
  }

  return (
    <main className="min-h-screen bg-[#05050a] pb-[100px]">
      {/* Danger stripe */}
      <div className="animate-danger-pulse h-1 w-full bg-[#f43f5e]" />

      {/* Header */}
      <div className="mx-auto max-w-[580px] px-4">
        <div className="pt-8 pb-6 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-[#f43f5e]" />
          <h1
            className="mt-3 text-2xl font-extrabold text-[#f43f5e] font-[family-name:var(--font-space-grotesk)]"
          >
            {t('emergency.title')}
          </h1>
          <p className="mt-2 text-sm text-[#64748b]">{t('emergency.subtitle')}</p>
        </div>

        {/* Warning cards */}
        <WarningCards t={t} />

        {/* Return calculator */}
        <ReturnCalculator t={t} />

        {/* Confirmation sequence */}
        <ConfirmationSequence
          t={t}
          check1={check1}
          check2={check2}
          confirmValue={confirmValue}
          onCheck1={() => setCheck1((v) => !v)}
          onCheck2={() => setCheck2((v) => !v)}
          onConfirmChange={setConfirmValue}
        />

        {/* Emergency button */}
        <EmergencyButton
          state={computeState()}
          t={t}
          onClick={handleWithdraw}
        />

        {/* FAQ Accordion */}
        <FaqAccordion t={t} />

        {/* Bottom support note */}
        <p className="mt-6 text-center text-xs text-[#64748b]">
          {t('emergency.support')}{' '}
          <button
            type="button"
            className="text-[#00f5d4] transition-opacity hover:opacity-80"
          >
            {t('emergency.supportLink')}
          </button>
        </p>
      </div>
    </main>
  )
}
