'use client'

import { useState, useEffect } from 'react'
import { ChevronDown, AlertTriangle, CheckCircle, XCircle, Loader2 } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

type StakeStatus = 'idle' | 'approving' | 'approved' | 'staking' | 'success' | 'error'

export function StakeActionPanel() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  const [amount, setAmount] = useState('')
  const [referral, setReferral] = useState('')
  const [status, setStatus] = useState<StakeStatus>('idle')
  const [showAllocation, setShowAllocation] = useState(false)

  const numAmount = parseFloat(amount) || 0

  useEffect(() => {
    if (numAmount > 0) {
      const timer = setTimeout(() => setShowAllocation(true), 50)
      return () => clearTimeout(timer)
    } else {
      setShowAllocation(false)
    }
  }, [numAmount])

  const halfAmount = numAmount > 0 ? (numAmount / 2).toLocaleString('en-US') + ' USDT' : '0 USDT'

  function handleApprove() {
    if (numAmount < 100) return
    setStatus('approving')
    setTimeout(() => setStatus('approved'), 2000)
  }

  function handleStake() {
    if (status !== 'approved') return
    setStatus('staking')
    setTimeout(() => setStatus('success'), 2500)
  }

  function handleReset() {
    setAmount('')
    setReferral('')
    setStatus('idle')
    setShowAllocation(false)
  }

  const isApproveDisabled = numAmount < 100 || status === 'approving' || status === 'approved' || status === 'staking'
  const isStakeDisabled = status !== 'approved'

  return (
    <div className="flex flex-col">
      {/* Amount Input */}
      <div>
        <div className="flex items-center justify-between">
          <span className="text-xs text-[#64748b]">{t('stake.amountLabel')}</span>
          <span className="font-mono text-xs text-[#64748b]">{t('stake.balance')}</span>
        </div>

        <div className="mt-2 flex h-[72px] items-center gap-4 rounded-xl border border-[#ffffff1a] bg-[#0d0d14] px-5">
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="flex-1 bg-transparent font-[family-name:var(--font-jetbrains-mono)] text-3xl text-[#f1f5f9] outline-none placeholder:text-[#334155] [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
            aria-label={t('stake.amountLabel')}
          />
          {/* Token selector pill */}
          <button
            type="button"
            className="flex shrink-0 items-center gap-2 rounded-full border border-[#ffffff0d] bg-[#13131e] px-3 py-1.5 transition-colors hover:border-[#ffffff1a]"
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#00f5d4] text-[10px] font-bold text-[#05050a]">U</span>
            <span className="text-sm font-semibold text-[#f1f5f9]">USDT</span>
            <ChevronDown className="h-3.5 w-3.5 text-[#64748b]" />
          </button>
        </div>

        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-[#64748b]">{t('stake.minStake')}</span>
          <button
            type="button"
            onClick={() => setAmount('2500')}
            className="rounded-full border border-[#ffffff1a] px-3 py-1 text-xs text-[#00f5d4] transition-colors hover:bg-[#00f5d410]"
          >
            {t('stake.max')}
          </button>
        </div>
      </div>

      {/* Allocation Preview */}
      <div
        className={`overflow-hidden transition-all duration-300 ease-out ${
          showAllocation ? 'mt-4 max-h-48 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="rounded-xl border border-[#ffffff0d] bg-[#0d0d14] p-4">
          <p className="text-[11px] uppercase tracking-widest text-[#64748b]" style={{ fontVariant: 'small-caps' }}>
            {t('stake.allocation')}
          </p>

          <div className="mt-3 flex flex-col gap-3">
            {/* Treasury row */}
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-[#64748b]">→</span>
                  <span className="text-sm text-[#64748b]">{t('stake.treasury')}</span>
                </div>
                <span className="font-[family-name:var(--font-jetbrains-mono)] text-sm text-[#64748b]">{halfAmount}</span>
              </div>
              <div className="mt-1.5 h-[3px] overflow-hidden rounded-full bg-[#1a1a2e]">
                <div className="h-full w-1/2 rounded-full bg-[#64748b]" />
              </div>
            </div>

            {/* Pool row */}
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-[#00f5d4]">→</span>
                  <span className="text-sm text-[#f1f5f9]">{t('stake.pool')}</span>
                </div>
                <span className="font-[family-name:var(--font-jetbrains-mono)] text-sm text-[#00f5d4]">{halfAmount}</span>
              </div>
              <div className="mt-1.5 h-[3px] overflow-hidden rounded-full bg-[#1a1a2e]">
                <div
                  className="h-full rounded-full bg-[#00f5d4] transition-all duration-500 ease-out"
                  style={{
                    width: showAllocation ? '50%' : '0%',
                    boxShadow: '0 0 8px #00f5d440',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Referral Input */}
      <div className="mt-6">
        <div className="flex items-center gap-2">
          <span className="text-[11px] uppercase tracking-wider text-[#64748b]" style={{ fontVariant: 'small-caps' }}>
            {t('stake.referralLabel')}
          </span>
          <span className="rounded-full bg-[#1a1a2e] px-2 py-0.5 text-[11px] text-[#64748b]">
            {t('stake.referralOptional')}
          </span>
        </div>
        <input
          type="text"
          value={referral}
          onChange={(e) => setReferral(e.target.value)}
          placeholder={t('stake.referralPlaceholder')}
          className="mt-2 h-[52px] w-full rounded-xl border border-[#ffffff0d] bg-[#0d0d14] px-5 font-[family-name:var(--font-jetbrains-mono)] text-sm text-[#f1f5f9] outline-none transition-colors placeholder:text-[#334155] focus:border-[#ffffff1a]"
          aria-label={t('stake.referralLabel')}
        />
        {/* Warning chip */}
        {referral.length > 0 && (
          <div
            className="mt-2 flex items-start gap-2 rounded-lg border px-4 py-2.5"
            style={{
              background: 'rgba(251,146,60,0.10)',
              borderColor: 'rgba(251,146,60,0.30)',
            }}
          >
            <AlertTriangle className="mt-px h-3.5 w-3.5 shrink-0 text-[#fb923c]" />
            <p className="text-xs text-[#fb923c]">{t('stake.referralWarning')}</p>
          </div>
        )}
      </div>

      {/* Step Indicator */}
      <p className="mt-6 text-xs text-[#334155]">{t('stake.step')}</p>

      {/* Action Buttons / Result */}
      {status === 'success' ? (
        <div
          className="mt-3 rounded-xl border p-5"
          style={{ background: 'rgba(16,185,129,0.10)', borderColor: 'rgba(16,185,129,0.40)' }}
        >
          <div className="flex items-center gap-3">
            <CheckCircle className="h-6 w-6 text-[#10b981]" />
            <span className="font-[family-name:var(--font-space-grotesk)] text-lg font-bold text-[#10b981]">
              {t('stake.success')}
            </span>
          </div>
          <p className="mt-2 font-[family-name:var(--font-jetbrains-mono)] text-xs text-[#64748b]">
            {t('stake.txLabel')} {t('stake.txHash')}
          </p>
          <a
            href="#"
            className="mt-1 inline-block text-xs text-[#00f5d4] hover:underline"
          >
            {t('stake.viewBscscan')}
          </a>
          <div className="mt-3">
            <button
              type="button"
              onClick={handleReset}
              className="rounded-full border border-[#ffffff1a] px-4 py-2 text-sm text-[#f1f5f9] transition-colors hover:bg-[#13131e]"
            >
              {t('stake.stakeAgain')}
            </button>
          </div>
        </div>
      ) : status === 'error' ? (
        <div
          className="mt-3 rounded-xl border p-5"
          style={{ background: 'rgba(244,63,94,0.10)', borderColor: 'rgba(244,63,94,0.40)' }}
        >
          <div className="flex items-center gap-3">
            <XCircle className="h-6 w-6 text-[#f43f5e]" />
            <span className="text-sm text-[#f43f5e]">交易失败，请重试</span>
          </div>
          <button
            type="button"
            onClick={handleReset}
            className="mt-3 rounded-full bg-[#00f5d4] px-5 py-2 text-sm font-bold text-[#05050a] transition-all hover:brightness-110"
          >
            {t('stake.retry')}
          </button>
        </div>
      ) : (
        <div className="mt-3 flex flex-col gap-3">
          {/* Approve button */}
          <button
            type="button"
            onClick={handleApprove}
            disabled={isApproveDisabled}
            className={`flex h-14 w-full items-center justify-center gap-2 rounded-full border text-sm font-semibold transition-all
              ${status === 'approved'
                ? 'border-[#10b981] text-[#10b981]'
                : isApproveDisabled && status !== 'approving'
                  ? 'cursor-not-allowed border-[#ffffff0d] text-[#334155]'
                  : 'border-[#ffffff1a] text-[#f1f5f9] hover:bg-[#13131e]'
              }`}
          >
            {status === 'approving' && (
              <Loader2 className="h-4 w-4 animate-spin text-[#00f5d4]" />
            )}
            {status === 'approved' && (
              <CheckCircle className="h-4 w-4" />
            )}
            {status === 'approving'
              ? t('stake.approving')
              : status === 'approved'
                ? t('stake.approved')
                : t('stake.approve')}
          </button>

          {/* Stake button */}
          <button
            type="button"
            onClick={handleStake}
            disabled={isStakeDisabled}
            className={`flex h-14 w-full items-center justify-center gap-2 rounded-full text-sm font-bold transition-all
              ${isStakeDisabled
                ? 'cursor-not-allowed bg-[#13131e] text-[#334155]'
                : status === 'staking'
                  ? 'bg-[#00f5d466] text-[#05050a]'
                  : 'bg-[#00f5d4] text-[#05050a] hover:scale-[1.02] hover:brightness-110'
              }`}
          >
            {status === 'staking' && (
              <Loader2 className="h-4 w-4 animate-spin" />
            )}
            {status === 'staking' ? t('stake.staking') : t('stake.stakeNow')}
          </button>
        </div>
      )}
    </div>
  )
}
