'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'
import { StakeActionPanel } from '@/components/stake/stake-action-panel'
import { StakeInfoPanelContent } from '@/components/stake/stake-info-panel'
import { StakeMobileAccordion } from '@/components/stake/stake-mobile-accordion'

export function StakePageClient() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <main className="mx-auto max-w-7xl px-4 pb-[100px] pt-8 lg:px-8">
      {/* Page Header */}
      <div className="pb-4">
        <p
          className="text-[11px] uppercase tracking-widest text-[#64748b]"
          style={{ fontVariant: 'small-caps' }}
        >
          {t('stake.overline')}
        </p>
        <h1 className="mt-1 font-[family-name:var(--font-space-grotesk)] text-3xl font-bold text-[#f1f5f9]">
          {t('stake.title')}
        </h1>
      </div>

      {/* Desktop: 60/40 asymmetric grid | Mobile: single column */}
      <div className="mt-6 grid grid-cols-1 gap-8 lg:grid-cols-[3fr_2fr]">

        {/* LEFT 60% — Action Panel + mobile accordion */}
        <div>
          <StakeActionPanel />
          <StakeMobileAccordion />
        </div>

        {/* RIGHT 40% — Sticky info card (desktop only) */}
        <aside className="hidden lg:block">
          <div className="sticky top-24 rounded-2xl border border-[#ffffff1a] bg-[#0d0d14] p-6 backdrop-blur-xl">
            <StakeInfoPanelContent />
          </div>
        </aside>
      </div>
    </main>
  )
}
