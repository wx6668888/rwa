'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Menu, X } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'
import { LanguageSwitcher } from '@/components/language-switcher'

const navKeys = [
  { key: 'nav.home',        href: '/' },
  { key: 'nav.stake',       href: '/stake' },
  { key: 'nav.withdraw',    href: '/withdraw' },
  { key: 'nav.dashboard',   href: '/dashboard' },
  { key: 'nav.nodes',       href: '/nodes' },
  { key: 'nav.governance',  href: '/governance' },
  { key: 'nav.emergency',   href: '/emergency', danger: true },
]

export function Navbar() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)
  const [mobileOpen, setMobileOpen] = useState(false)
  const pathname = usePathname()

  function isActive(href: string) {
    if (href === '/') return pathname === '/'
    return pathname.startsWith(href)
  }

  return (
    <header className="sticky top-0 z-50 h-16 border-b border-[#ffffff0d] bg-[#05050a99] backdrop-blur-xl">
      <nav className="mx-auto flex h-full max-w-7xl items-center justify-between px-4 lg:px-8">
        {/* Left: Logo */}
        <Link href="/" className="flex items-center gap-2 font-[family-name:var(--font-space-grotesk)]">
          <span className="text-lg font-bold tracking-tight text-[#00f5d4]">RWA</span>
          <span className="mx-1 h-4 w-px bg-[#ffffff1a]" />
          <span className="text-sm font-medium tracking-wider text-[#64748b]">PROTOCOL</span>
        </Link>

        {/* Center: Desktop Nav */}
        <div className="hidden items-center gap-1 md:flex">
          {navKeys.map((item) => {
            const active = isActive(item.href)
            const isDanger = (item as { danger?: boolean }).danger
            return (
              <Link
                key={item.key}
                href={item.href}
                className={`relative flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                  active
                    ? isDanger ? 'text-[#f43f5e]' : 'text-[#00f5d4]'
                    : isDanger
                    ? 'text-[#f43f5e80] hover:bg-[#13131e] hover:text-[#f43f5e]'
                    : 'text-[#64748b] hover:bg-[#13131e] hover:text-[#f1f5f9]'
                }`}
              >
                {t(item.key)}
                {isDanger && (
                  <span className="rounded-full bg-[#f43f5e] px-1.5 py-0.5 text-[9px] font-bold uppercase leading-none tracking-wider text-white">
                    !!
                  </span>
                )}
                {active && !isDanger && (
                  <span className="absolute bottom-0 left-1/2 h-0.5 w-4 -translate-x-1/2 rounded-full bg-[#00f5d4]" style={{ boxShadow: '0 0 8px #00f5d440' }} />
                )}
                {active && isDanger && (
                  <span className="absolute bottom-0 left-1/2 h-0.5 w-4 -translate-x-1/2 rounded-full bg-[#f43f5e]" style={{ boxShadow: '0 0 8px #f43f5e40' }} />
                )}
              </Link>
            )
          })}
        </div>

        {/* Right: Language + Wallet */}
        <div className="flex items-center gap-2">
          <div className="hidden md:block">
            <LanguageSwitcher />
          </div>
          <Link
            href="/dashboard"
            className="rounded-full bg-[#00f5d4] px-5 py-2 font-[family-name:var(--font-space-grotesk)] text-sm font-semibold text-[#05050a] transition-all hover:scale-[1.02] hover:brightness-110"
          >
            {t('nav.connectWallet')}
          </Link>
          {/* Mobile hamburger */}
          <button
            type="button"
            onClick={() => setMobileOpen(!mobileOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-[#f1f5f9] transition-colors hover:bg-[#13131e] md:hidden"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-y-0 end-0 z-50 w-72 border-s border-[#ffffff0d] bg-[#0d0d14] p-6 shadow-2xl md:hidden">
          <div className="flex items-center justify-between">
            <LanguageSwitcher />
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-[#f1f5f9] hover:bg-[#13131e]"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="mt-8 flex flex-col gap-2">
            {navKeys.map((item) => {
              const active = isActive(item.href)
              const isDanger = (item as { danger?: boolean }).danger
              return (
                <Link
                  key={item.key}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center justify-between rounded-lg px-4 py-3 text-base font-medium transition-colors ${
                    active
                      ? isDanger ? 'text-[#f43f5e]' : 'text-[#00f5d4]'
                      : isDanger
                      ? 'text-[#f43f5e80] hover:bg-[#13131e] hover:text-[#f43f5e]'
                      : 'text-[#64748b] hover:bg-[#13131e] hover:text-[#f1f5f9]'
                  }`}
                >
                  {t(item.key)}
                  {isDanger && (
                    <span className="rounded-full bg-[#f43f5e] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
                      !!
                    </span>
                  )}
                </Link>
              )
            })}
          </div>
        </div>
      )}
    </header>
  )
}
