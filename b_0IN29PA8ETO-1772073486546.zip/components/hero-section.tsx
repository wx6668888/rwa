'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'
import { HexNetwork } from '@/components/hex-network'

export function HeroSection() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <section className="relative mx-auto flex max-w-7xl flex-col items-center gap-12 px-4 pt-20 pb-16 lg:flex-row lg:items-center lg:gap-16 lg:px-8 lg:pt-28 lg:pb-24">
      {/* Left 60% */}
      <div className="flex-[3] space-y-6">
        {/* Overline */}
        <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-text-secondary">
          {t('hero.overline').split('·').map((part, i, arr) => (
            <span key={i}>
              {part.trim()}
              {i < arr.length - 1 && (
                <span className="mx-2 inline-block h-1 w-1 rounded-full bg-plasma-cyan align-middle" />
              )}
            </span>
          ))}
        </p>

        {/* H1 */}
        <h1 className="font-[family-name:var(--font-space-grotesk)] text-[40px] font-black leading-[1.1] text-text-primary lg:text-[72px]">
          <span className="text-plasma-cyan">{t('hero.titleLine1Start')}</span>
          {t('hero.titleLine1End')}
          <br />
          <span className="text-plasma-cyan">{t('hero.titleLine2Start')}</span>
          {t('hero.titleLine2End')}
        </h1>

        {/* Subtitle */}
        <p className="max-w-md text-base leading-relaxed text-text-secondary lg:text-lg">
          {t('hero.subtitle')}
        </p>

        {/* Button Row */}
        <div className="flex flex-wrap items-center gap-4 pt-2">
          <button
            type="button"
            className="rounded-full bg-plasma-cyan px-8 py-3 font-[family-name:var(--font-space-grotesk)] text-base font-semibold text-void-black transition-all hover:scale-[1.02] hover:brightness-110"
          >
            {t('hero.cta1')} {'\u2192'}
          </button>
          <button
            type="button"
            className="rounded-full border border-border-active px-8 py-3 text-base font-medium text-text-primary transition-colors hover:bg-surface-2"
          >
            {t('hero.cta2')}
          </button>
        </div>

        {/* Trust Signals */}
        <div className="flex flex-wrap items-center gap-4 pt-2 text-[12px] font-medium uppercase tracking-[0.15em] text-text-secondary">
          <span>{'🔒'} {t('hero.trust1')}</span>
          <span className="h-1 w-1 rounded-full bg-plasma-cyan" />
          <span>{'⛓'} {t('hero.trust2')}</span>
          <span className="h-1 w-1 rounded-full bg-plasma-cyan" />
          <span>{'🏛'} {t('hero.trust3')}</span>
        </div>
      </div>

      {/* Right 40% — hex network (desktop only) */}
      <div className="hidden flex-[2] lg:block">
        <div className="h-[400px] w-full">
          <HexNetwork />
        </div>
      </div>
    </section>
  )
}
