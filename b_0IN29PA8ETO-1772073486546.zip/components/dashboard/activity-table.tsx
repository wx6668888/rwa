'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

interface TypePillProps {
  label: string
  variant: 'cyan' | 'purple' | 'neutral'
}

function TypePill({ label, variant }: TypePillProps) {
  const styles: Record<string, { bg: string; color: string }> = {
    cyan:    { bg: 'rgba(0,245,212,0.15)',  color: '#00f5d4' },
    purple:  { bg: 'rgba(139,92,246,0.15)', color: '#8b5cf6' },
    neutral: { bg: '#1a1a2e',               color: '#64748b' },
  }
  const s = styles[variant]
  return (
    <span
      className="rounded-full px-2.5 py-0.5 text-[11px] font-medium"
      style={{ background: s.bg, color: s.color }}
    >
      {label}
    </span>
  )
}

interface ActivityRow {
  time: string
  type: string
  typeVariant: 'cyan' | 'purple' | 'neutral'
  amount: string
  amountColor: string
  status: string
}

export function ActivityTable() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  const rows: ActivityRow[] = [
    {
      time: t('activity.row1Time'),
      type: t('activity.row1Type'),
      typeVariant: 'cyan',
      amount: t('activity.row1Amount'),
      amountColor: '#00f5d4',
      status: t('activity.confirmed'),
    },
    {
      time: t('activity.row2Time'),
      type: t('activity.row2Type'),
      typeVariant: 'purple',
      amount: t('activity.row2Amount'),
      amountColor: '#8b5cf6',
      status: t('activity.confirmed'),
    },
    {
      time: t('activity.row3Time'),
      type: t('activity.row3Type'),
      typeVariant: 'neutral',
      amount: t('activity.row3Amount'),
      amountColor: '#f1f5f9',
      status: t('activity.confirmed'),
    },
  ]

  return (
    <div
      className="rounded-2xl bg-[#0d0d14] p-6 backdrop-blur-xl"
      style={{ border: '1px solid #ffffff0d' }}
    >
      {/* Header row */}
      <div className="mb-4 flex items-center justify-between">
        <span
          className="text-[13px] uppercase tracking-widest text-[#64748b]"
          style={{ fontVariant: 'small-caps' }}
        >
          {t('activity.title')}
        </span>
        <button
          type="button"
          className="text-[13px] text-[#00f5d4] transition-opacity hover:opacity-70"
        >
          {t('activity.viewAll')}
        </button>
      </div>

      {/* Table — horizontal scroll on mobile */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[500px]">
          <thead>
            <tr className="border-b border-[#ffffff0d]">
              {[
                t('activity.colTime'),
                t('activity.colType'),
                t('activity.colAmount'),
                t('activity.colStatus'),
              ].map((col) => (
                <th
                  key={col}
                  className="pb-3 text-start text-[11px] uppercase tracking-widest text-[#334155]"
                  style={{ fontVariant: 'small-caps' }}
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr
                key={i}
                className="border-b border-[#ffffff0d] transition-colors hover:bg-[#13131e]"
              >
                <td className="sticky start-0 bg-inherit py-4 pe-4 font-mono text-[13px] text-[#64748b]">
                  {row.time}
                </td>
                <td className="py-4 pe-4">
                  <TypePill label={row.type} variant={row.typeVariant} />
                </td>
                <td className="py-4 pe-4">
                  <span className="font-mono text-[13px]" style={{ color: row.amountColor }}>
                    {row.amount}
                  </span>
                </td>
                <td className="py-4">
                  <span className="flex items-center gap-1 text-[12px] text-[#10b981]">
                    {row.status}
                    <span>&#10003;</span>
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
