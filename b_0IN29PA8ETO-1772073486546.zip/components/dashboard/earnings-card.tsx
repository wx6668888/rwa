'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

export function EarningsCard() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <div
      className="rounded-2xl bg-[#0d0d14] p-6 backdrop-blur-xl"
      style={{ border: '1px solid #ffffff1a' }}
    >
      <div className="flex h-full flex-col gap-0 md:flex-row">
        {/* LEFT: RWA */}
        <div className="flex flex-1 flex-col">
          <p
            className="text-[11px] uppercase tracking-widest text-[#64748b]"
            style={{ fontVariant: 'small-caps' }}
          >
            {t('earnings.rwa')}
          </p>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="font-mono text-[40px] font-bold leading-none text-[#f1f5f9]">1,245.67</span>
            <span className="font-mono text-lg text-[#00f5d4]">{t('earnings.rwaCurrency')}</span>
          </div>
          <p className="mt-1 text-[13px] text-[#64748b]">{t('earnings.usdtEquiv')}</p>
          <button
            type="button"
            className="mt-4 min-h-[44px] w-full rounded-full bg-[#00f5d4] font-[family-name:var(--font-space-grotesk)] text-sm font-semibold text-[#05050a] transition-all hover:brightness-110"
          >
            {t('earnings.withdrawRwa')}
          </button>
        </div>

        {/* Vertical divider (desktop) / Horizontal (mobile) */}
        <div className="mx-6 hidden w-px bg-[#ffffff0d] md:block" />
        <div className="my-5 h-px bg-[#ffffff0d] md:hidden" />

        {/* RIGHT: USDT */}
        <div className="flex flex-1 flex-col">
          <p
            className="text-[11px] uppercase tracking-widest text-[#64748b]"
            style={{ fontVariant: 'small-caps' }}
          >
            {t('earnings.usdt')}
          </p>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="font-mono text-[40px] font-bold leading-none text-[#f1f5f9]">85.40</span>
            <span className="font-mono text-lg text-[#8b5cf6]">USDT</span>
          </div>
          <p className="mt-1 text-[13px] text-[#64748b]">{t('earnings.dynamic')}</p>
          <button
            type="button"
            className="mt-4 min-h-[44px] w-full rounded-full bg-[#8b5cf6] font-[family-name:var(--font-space-grotesk)] text-sm font-semibold text-white transition-all hover:brightness-110"
          >
            {t('earnings.claimUsdt')}
          </button>
        </div>
      </div>
    </div>
  )
}
