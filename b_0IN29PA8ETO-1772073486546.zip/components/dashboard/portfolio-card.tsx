'use client'

import { ExternalLink } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

function CircleProgress({ percent, size = 60, strokeWidth = 4 }: { percent: number; size?: number; strokeWidth?: number }) {
  const r = (size - strokeWidth) / 2
  const circ = 2 * Math.PI * r
  const offset = circ - (percent / 100) * circ

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        {/* track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#1a1a2e"
          strokeWidth={strokeWidth}
        />
        {/* progress */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#00f5d4"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
        {/* center text — counter-rotate */}
        <text
          x={size / 2}
          y={size / 2}
          textAnchor="middle"
          dominantBaseline="central"
          fontSize="13"
          fontFamily="'JetBrains Mono', monospace"
          fill="#00f5d4"
          style={{ transform: `rotate(90deg)`, transformOrigin: `${size / 2}px ${size / 2}px` }}
        >
          {percent}%
        </text>
      </svg>
    </div>
  )
}

function ProgressBar({ fill, label, value }: { fill: number; label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center justify-between">
        <span className="text-[12px] text-[#64748b]">{label}</span>
        <span className="font-mono text-[12px] text-[#64748b]">{value}</span>
      </div>
      <div className="h-1 w-full overflow-hidden rounded-full bg-[#1a1a2e]">
        <div
          className="h-full rounded-full bg-[#00f5d4]"
          style={{ width: `${fill}%` }}
        />
      </div>
    </div>
  )
}

export function PortfolioCard() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <div
      className="relative overflow-hidden rounded-2xl bg-[#0d0d14] p-6 backdrop-blur-xl"
      style={{
        border: '1px solid #00f5d4',
        boxShadow: '0 0 20px #00f5d420',
      }}
    >
      {/* Subtle inner glow */}
      <div
        className="pointer-events-none absolute inset-0 rounded-2xl"
        style={{ background: 'radial-gradient(ellipse at top left, #00f5d408 0%, transparent 60%)' }}
      />

      {/* Label */}
      <p className="text-[11px] uppercase tracking-widest text-[#64748b]" style={{ fontVariant: 'small-caps' }}>
        {t('portfolio.label')}
      </p>

      {/* Value */}
      <div className="mt-1 flex items-baseline gap-2">
        <span className="font-mono text-5xl font-bold text-[#f1f5f9]">5,000.00</span>
        <span className="font-mono text-xl text-[#00f5d4]">{t('portfolio.currency')}</span>
      </div>

      <div className="my-4 h-px bg-[#ffffff0d]" />

      {/* Node level row */}
      <div className="flex items-start justify-between">
        {/* Left: Hex badge */}
        <div className="flex flex-col items-center gap-1.5">
          <div className="relative">
            {/* Animated ring */}
            <svg width="64" height="64" viewBox="0 0 64 64" className="absolute inset-0">
              <polygon
                points="32,4 58,18 58,46 32,60 6,46 6,18"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="1.5"
                strokeDasharray="6 3"
                className="animate-spin-slow"
                style={{ transformOrigin: '32px 32px', opacity: 0.6 }}
              />
            </svg>
            {/* Main hex */}
            <svg width="64" height="64" viewBox="0 0 64 64">
              <polygon
                points="32,8 56,21 56,43 32,56 8,43 8,21"
                fill="#13131e"
                stroke="#f59e0b"
                strokeWidth="1.5"
                style={{ filter: 'drop-shadow(0 0 10px #f59e0b40)' }}
              />
              <text
                x="32"
                y="32"
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="14"
                fontFamily="'Space Grotesk', sans-serif"
                fontWeight="700"
                fill="#f59e0b"
              >
                {t('nodeLevel.badge')}
              </text>
            </svg>
          </div>
          <span
            className="text-[11px] uppercase tracking-widest text-[#f59e0b]"
            style={{ fontVariant: 'small-caps' }}
          >
            {t('nodeLevel.name')}
          </span>
        </div>

        {/* Right: Circle progress */}
        <div className="flex flex-col items-center gap-1">
          <CircleProgress percent={42} />
          <span className="mt-1 text-[11px] text-[#64748b]">{t('portfolio.toV3')}</span>
        </div>
      </div>

      {/* Requirements */}
      <div className="mt-4 flex flex-col gap-2">
        <p
          className="text-[11px] uppercase tracking-widest text-[#64748b]"
          style={{ fontVariant: 'small-caps' }}
        >
          {t('portfolio.requirements')}
        </p>
        <ProgressBar label={t('portfolio.req1')} value="1/3" fill={33} />
        <ProgressBar label={t('portfolio.req2')} value="8,432/20,000 USDT" fill={42} />
      </div>

      {/* Referrer */}
      <div className="mt-4 flex items-center gap-1.5">
        <span className="text-[12px] text-[#64748b]">{t('portfolio.referrer')}</span>
        <span className="font-mono text-[12px] text-[#f1f5f9]">{t('portfolio.referrerAddress')}</span>
        <ExternalLink className="h-3 w-3 text-[#64748b]" />
      </div>
    </div>
  )
}
