'use client'

import { useState } from 'react'
import { Check, Copy } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

export function WalletBar() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)
  const [copied, setCopied] = useState(false)

  function handleCopy() {
    navigator.clipboard.writeText('0x1234567890abcdef5678').catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="w-full border-b border-[#ffffff0d] bg-[#0d0d14] px-6" style={{ height: 48 }}>
      <div className="mx-auto flex h-full max-w-7xl items-center justify-between">
        {/* Left: address + network */}
        <div className="flex items-center gap-3">
          {/* Pulsing green dot */}
          <span className="relative flex h-2 w-2">
            <span className="animate-dot-pulse absolute inline-flex h-full w-full rounded-full bg-[#10b981] opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-[#10b981]" />
          </span>

          {/* Address chip */}
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 rounded-md border border-[#ffffff0d] bg-[#13131e] px-3 py-1 transition-colors hover:border-[#ffffff1a]"
            aria-label="复制钱包地址"
          >
            <span className="font-mono text-xs text-[#f1f5f9]">
              {t('wallet.address')}
            </span>
            {copied ? (
              <Check className="h-3 w-3 text-[#10b981]" />
            ) : (
              <Copy className="h-3 w-3 text-[#64748b]" />
            )}
          </button>

          {/* Network pill */}
          <span className="rounded-full border border-[#ffffff0d] bg-[#1a1a2e] px-2 py-0.5 font-mono text-[11px] text-[#64748b]">
            {t('wallet.network')}
          </span>
        </div>

        {/* Right: disconnect */}
        <button
          type="button"
          className="text-[12px] text-[#64748b] transition-colors hover:text-[#f1f5f9]"
        >
          {t('wallet.disconnect')}
        </button>
      </div>
    </div>
  )
}
