'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

interface StatCardProps {
  label: string
  value: string
  valueColor?: string
}

function StatCard({ label, value, valueColor = '#f1f5f9' }: StatCardProps) {
  return (
    <div
      className="flex min-w-[160px] flex-1 flex-col gap-2 rounded-2xl bg-[#0d0d14] p-5 transition-all duration-200 hover:-translate-y-0.5"
      style={{ border: '1px solid #ffffff0d' }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor = '#ffffff1a'
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor = '#ffffff0d'
      }}
    >
      <p
        className="text-[11px] uppercase tracking-widest text-[#64748b]"
        style={{ fontVariant: 'small-caps' }}
      >
        {label}
      </p>
      <p className="font-mono text-2xl font-bold" style={{ color: valueColor }}>
        {value}
      </p>
    </div>
  )
}

export function StatCards() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    /* Mobile: horizontal scroll; Desktop: 3 equal columns */
    <div className="flex gap-4 overflow-x-auto pb-1 md:grid md:grid-cols-3 md:overflow-visible md:pb-0">
      <StatCard
        label={t('stats.teamVol')}
        value={t('stats.teamVolValue')}
        valueColor="#00f5d4"
      />
      <StatCard
        label={t('stats.directRefs')}
        value={t('stats.directRefsValue')}
        valueColor="#f1f5f9"
      />
      <StatCard
        label={t('stats.totalEarned')}
        value={t('stats.totalEarnedValue')}
        valueColor="#8b5cf6"
      />
    </div>
  )
}
