'use client'

import { LiveIndicatorBar } from '@/components/governance/live-indicator-bar'
import { ProtocolParams } from '@/components/governance/protocol-params'
import { TreasuryPool } from '@/components/governance/treasury-pool'
import { TimelockQueue } from '@/components/governance/timelock-queue'
import { ActivityFeed } from '@/components/governance/activity-feed'

export function GovernancePageClient() {
  return (
    <>
      <LiveIndicatorBar />
      <main className="relative mx-auto max-w-5xl px-4 pb-24 pt-10 lg:px-8">
        <ProtocolParams />
        <TreasuryPool />
        <TimelockQueue />
        <ActivityFeed />
      </main>
    </>
  )
}
