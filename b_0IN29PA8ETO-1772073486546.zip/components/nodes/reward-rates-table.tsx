'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

const RATES = [
  { code: 'V1', nameKey: 'nodes.v1name', rate: '5%',  reqKey: 'nodes.v1req', color: '#64748b',  current: false },
  { code: 'V2', nameKey: 'nodes.v2name', rate: '10%', reqKey: 'nodes.v2req', color: '#00f5d4',  current: true  },
  { code: 'V3', nameKey: 'nodes.v3name', rate: '15%', reqKey: 'nodes.v3req', color: '#10b981',  current: false },
  { code: 'V4', nameKey: 'nodes.v4name', rate: '20%', reqKey: 'nodes.v4req', color: '#8b5cf6',  current: false },
  { code: 'V5', nameKey: 'nodes.v5name', rate: '50%', reqKey: 'nodes.v5req', color: '#f59e0b',  current: false },
]

function MiniHex({ color, code }: { color: string; code: string }) {
  const size = 24
  const r = size / 2
  const pts = Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 180) * (60 * i - 30)
    return `${r + (r - 2) * Math.cos(a)},${r + (r - 2) * Math.sin(a)}`
  }).join(' ')
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <polygon points={pts} fill="transparent" stroke={color} strokeWidth="1.5" />
      <text
        x="50%" y="54%"
        textAnchor="middle" dominantBaseline="middle"
        fontSize="7"
        fontWeight="700"
        fill={color}
        fontFamily="var(--font-space-grotesk), sans-serif"
      >
        {code}
      </text>
    </svg>
  )
}

export function RewardRatesTable() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <div className="overflow-hidden rounded-2xl border border-[#ffffff0d] bg-[#0d0d14] backdrop-blur-xl">
      {/* Header */}
      <div className="border-b border-[#ffffff0d] px-5 py-5">
        <p className="text-[13px] uppercase tracking-widest text-[#64748b]" style={{ fontVariant: 'small-caps' }}>
          {t('nodes.ratesTitle')}
        </p>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#ffffff0d]">
              {['nodes.colLevel', 'nodes.colName', 'nodes.colRate', 'nodes.colReq'].map((key) => (
                <th
                  key={key}
                  className="px-5 py-3 text-left text-[11px] uppercase tracking-wider text-[#334155]"
                  style={{ fontVariant: 'small-caps' }}
                >
                  {t(key)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {RATES.map((row) => (
              <tr
                key={row.code}
                className={`border-b border-[#ffffff0d] transition-colors last:border-0 ${
                  row.current ? 'bg-[#13131e]' : 'hover:bg-[#0d0d1480]'
                }`}
                style={row.current ? { borderLeft: '3px solid #00f5d4' } : { borderLeft: '3px solid transparent' }}
              >
                <td className="px-5 py-4">
                  <div className="flex items-center gap-2">
                    <MiniHex color={row.color} code={row.code} />
                    <span
                      className="font-[family-name:var(--font-space-grotesk)] text-[13px] font-semibold"
                      style={{ color: row.current ? '#00f5d4' : '#64748b' }}
                    >
                      {row.code}
                    </span>
                  </div>
                </td>
                <td className="px-5 py-4 text-[14px] text-[#f1f5f9]">
                  {t(row.nameKey)}
                </td>
                <td className="px-5 py-4">
                  <span
                    className="font-[family-name:var(--font-jetbrains-mono)] text-[16px] font-bold"
                    style={{ color: row.current ? '#00f5d4' : '#64748b' }}
                  >
                    {row.rate}
                  </span>
                </td>
                <td className="px-5 py-4 text-[12px] text-[#64748b]">
                  {t(row.reqKey)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
