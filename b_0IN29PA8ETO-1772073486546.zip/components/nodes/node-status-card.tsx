'use client'

import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

const LEVELS = [
  { code: 'V1', color: '#64748b', glowColor: 'transparent', nameKey: 'nodes.v1name', done: true },
  { code: 'V2', color: '#f59e0b', glowColor: '#f59e0b40', nameKey: 'nodes.v2name', current: true },
  { code: 'V3', color: '#1a1a2e', glowColor: 'transparent', nameKey: 'nodes.v3name', locked: true },
  { code: 'V4', color: '#1a1a2e', glowColor: 'transparent', nameKey: 'nodes.v4name', locked: true },
  { code: 'V5', color: '#1a1a2e', glowColor: 'transparent', nameKey: 'nodes.v5name', locked: true },
]

function HexSvg({ size, stroke, fill, textColor, text, glow }: {
  size: number; stroke: string; fill: string; textColor: string; text: string; glow?: string
}) {
  const r = size / 2
  const pts = Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 180) * (60 * i - 30)
    return `${r + (r - 3) * Math.cos(a)},${r + (r - 3) * Math.sin(a)}`
  }).join(' ')
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={glow ? { filter: `drop-shadow(0 0 10px ${glow})` } : {}}>
      <polygon points={pts} fill={fill} stroke={stroke} strokeWidth="2" />
      <text
        x="50%" y="54%"
        textAnchor="middle" dominantBaseline="middle"
        fontSize={size * 0.28}
        fontWeight="700"
        fill={textColor}
        fontFamily="var(--font-space-grotesk), sans-serif"
      >
        {text}
      </text>
    </svg>
  )
}

function LevelStepper() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <div className="mt-8 flex items-center justify-center gap-0">
      {LEVELS.map((lvl, i) => (
        <div key={lvl.code} className="flex items-center">
          <div className="flex flex-col items-center gap-1.5">
            {lvl.current ? (
              <HexSvg size={44} stroke={lvl.color} fill="#13131e" textColor={lvl.color} text={lvl.code} glow={lvl.glowColor} />
            ) : lvl.done ? (
              <HexSvg size={44} stroke="#00f5d4" fill="#00f5d4" textColor="#05050a" text={lvl.code} />
            ) : (
              <div className="relative">
                <HexSvg size={44} stroke="#ffffff0d" fill="#1a1a2e" textColor="#334155" text="" />
                {/* Lock icon */}
                <svg className="absolute inset-0 m-auto" width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="#334155" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
              </div>
            )}
            <span
              className="text-[11px]"
              style={{ color: lvl.current ? '#f59e0b' : lvl.done ? '#00f5d4' : '#334155' }}
            >
              {t(lvl.nameKey)}
            </span>
          </div>
          {i < LEVELS.length - 1 && (
            <div
              className="mx-1 h-px w-8"
              style={{
                background: i === 0
                  ? 'linear-gradient(90deg, #00f5d4, #00f5d4)'
                  : '#1a1a2e',
                borderTop: i > 0 ? '1px dashed #334155' : undefined,
                background: i > 0 ? 'none' : 'linear-gradient(90deg, #00f5d4, #f59e0b)',
              }}
            />
          )}
        </div>
      ))}
    </div>
  )
}

function RequirementsCard() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <div className="mx-auto mt-6 max-w-sm rounded-2xl border border-[#ffffff0d] bg-transparent p-5 text-left">
      <p className="text-[11px] uppercase tracking-widest text-[#64748b]" style={{ fontVariant: 'small-caps' }}>
        {t('nodes.reqTitle')}
      </p>
      <div className="mt-3 flex flex-col gap-4">
        {/* Row 1 */}
        <div>
          <div className="flex justify-between">
            <span className="text-[13px] text-[#64748b]">{t('nodes.req1label')}</span>
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-[13px] text-[#64748b]">
              {t('nodes.req1progress')}
            </span>
          </div>
          <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-[#1a1a2e]">
            <div className="h-full w-[33%] rounded-full bg-[#00f5d4]" />
          </div>
          <p className="mt-1 text-[11px] text-[#64748b]">{t('nodes.req1hint')}</p>
        </div>
        {/* Row 2 */}
        <div>
          <div className="flex justify-between">
            <span className="text-[13px] text-[#64748b]">{t('nodes.req2label')}</span>
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-[13px] text-[#64748b]">
              {t('nodes.req2progress')}
            </span>
          </div>
          <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-[#1a1a2e]">
            <div className="h-full w-[42%] rounded-full bg-[#00f5d4]" />
          </div>
          <p className="mt-1 text-[11px] text-[#64748b]">{t('nodes.req2hint')}</p>
        </div>
        {/* Row 3 — met */}
        <div>
          <div className="flex justify-between">
            <span className="text-[13px] text-[#64748b]">{t('nodes.req3label')}</span>
            <span className="font-[family-name:var(--font-jetbrains-mono)] text-[13px] text-[#64748b]">
              {t('nodes.req3progress')}
            </span>
          </div>
          <div className="mt-1 flex items-center gap-1">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
            <p className="text-[11px] text-[#10b981]">{t('nodes.req3hint')}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export function NodeStatusCard() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)

  return (
    <div className="rounded-2xl border border-[#ffffff1a] bg-[#0d0d14] p-8 text-center backdrop-blur-xl">
      {/* Large hexagon badge */}
      <div className="flex justify-center" style={{ filter: 'drop-shadow(0 0 40px #f59e0b30)' }}>
        <svg width="120" height="120" viewBox="0 0 120 120">
          {/* Outer dashed rotating ring */}
          <g style={{ animation: 'spin-slow 20s linear infinite', transformOrigin: '60px 60px' }}>
            {Array.from({ length: 6 }, (_, i) => {
              const a = (Math.PI / 180) * (60 * i - 30)
              return `${60 + 56 * Math.cos(a)},${60 + 56 * Math.sin(a)}`
            }).join(' ')}
            <polygon
              points={Array.from({ length: 6 }, (_, i) => {
                const a = (Math.PI / 180) * (60 * i - 30)
                return `${60 + 56 * Math.cos(a)},${60 + 56 * Math.sin(a)}`
              }).join(' ')}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="1.5"
              strokeDasharray="8 4"
            />
          </g>
          {/* Inner hexagon */}
          <polygon
            points={Array.from({ length: 6 }, (_, i) => {
              const a = (Math.PI / 180) * (60 * i - 30)
              return `${60 + 44 * Math.cos(a)},${60 + 44 * Math.sin(a)}`
            }).join(' ')}
            fill="#13131e"
            stroke="#f59e0b"
            strokeWidth="2"
          />
          {/* V2 text */}
          <text
            x="60" y="62"
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize="38"
            fontWeight="900"
            fill="#f59e0b"
            fontFamily="var(--font-space-grotesk), sans-serif"
          >
            V2
          </text>
        </svg>
      </div>

      {/* Node name */}
      <p className="mt-3 text-[13px] uppercase tracking-widest text-[#f59e0b]" style={{ fontVariant: 'small-caps' }}>
        {t('nodes.v2name')}
      </p>

      {/* Level stepper */}
      <LevelStepper />

      {/* Requirements card */}
      <RequirementsCard />
    </div>
  )
}
