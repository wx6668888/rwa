'use client'

import { useState, useCallback } from 'react'
import Link from 'next/link'
import { useLocale } from '@/components/locale-provider'
import { useTranslation } from '@/lib/i18n'

const TREE_NODES = [
  { id: 'root', x: 300, y: 44,  label: 'nodes.me',   addr: '0x1234...5678', sub: 'V2 · 5,000 USDT', stroke: '#00f5d4', glow: true  },
  { id: 'c1',   x: 110, y: 148, label: null,          addr: '0xAb...12',     sub: 'V1 · 200U',       stroke: '#64748b', glow: false },
  { id: 'c2',   x: 300, y: 148, label: null,          addr: '0xCd...34',     sub: 'V2 · 1,500U',     stroke: '#00f5d4', glow: false },
  { id: 'c3',   x: 490, y: 148, label: null,          addr: '0xEf...56',     sub: 'V1 · 300U',       stroke: '#64748b', glow: false },
]

function HexNode({ x, y, stroke, glow, label, addr, sub, onHover, onLeave, isHovered, tMe }: {
  x: number; y: number; stroke: string; glow: boolean; label: string | null
  addr: string; sub: string; onHover: () => void; onLeave: () => void; isHovered: boolean; tMe: string
}) {
  const size = 56
  const r = size / 2
  const pts = Array.from({ length: 6 }, (_, i) => {
    const a = (Math.PI / 180) * (60 * i - 30)
    return `${x + (r - 3) * Math.cos(a)},${y + (r - 3) * Math.sin(a)}`
  }).join(' ')

  return (
    <g
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      style={{ cursor: 'pointer' }}
    >
      {glow && (
        <polygon
          points={pts}
          fill="none"
          stroke="#00f5d4"
          strokeWidth="6"
          opacity="0.12"
        />
      )}
      <polygon
        points={pts}
        fill="#13131e"
        stroke={stroke}
        strokeWidth={isHovered ? 2.5 : 1.8}
        style={{ transition: 'stroke-width 0.15s' }}
      />
      <text
        x={x} y={y - 3}
        textAnchor="middle"
        dominantBaseline="middle"
        fontSize="11"
        fontWeight="700"
        fill={stroke}
        fontFamily="var(--font-space-grotesk), sans-serif"
      >
        {label ? tMe : addr.slice(0, 6)}
      </text>
      {/* Sub label below hex */}
      <text
        x={x} y={y + r + 12}
        textAnchor="middle"
        dominantBaseline="middle"
        fontSize="9"
        fill="#64748b"
        fontFamily="var(--font-jetbrains-mono), monospace"
      >
        {sub}
      </text>

      {/* Tooltip on hover */}
      {isHovered && (
        <g>
          <rect
            x={x - 72} y={y - r - 48}
            width={144} height={38}
            rx="6" ry="6"
            fill="#1a1a2e"
            stroke="#ffffff1a"
            strokeWidth="1"
          />
          <text x={x} y={y - r - 34} textAnchor="middle" fontSize="10" fill="#f1f5f9" fontFamily="var(--font-jetbrains-mono), monospace">
            {addr}
          </text>
          <text x={x} y={y - r - 20} textAnchor="middle" fontSize="9" fill="#64748b" fontFamily="var(--font-jetbrains-mono), monospace">
            {sub}
          </text>
        </g>
      )}
    </g>
  )
}

export function ReferralNetwork() {
  const { locale } = useLocale()
  const { t } = useTranslation(locale)
  const [copied, setCopied] = useState(false)
  const [hoveredId, setHoveredId] = useState<string | null>(null)

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText('0x1234...5678').catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }, [])

  const root = TREE_NODES[0]
  const children = TREE_NODES.slice(1)

  return (
    <div className="space-y-4">
      {/* Section header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-[family-name:var(--font-space-grotesk)] text-base font-bold text-[#f1f5f9]">
          {t('nodes.networkTitle')}
        </h2>
        <div className="flex gap-2">
          {(['nodes.chipDirect', 'nodes.chipTeam', 'nodes.chipVol'] as const).map((key) => (
            <span
              key={key}
              className="rounded-full border border-[#ffffff0d] bg-[#13131e] px-3 py-1 text-[11px] text-[#64748b]"
            >
              {t(key)}
            </span>
          ))}
        </div>
      </div>

      {/* Referral link card */}
      <div className="rounded-2xl border border-[#ffffff0d] bg-transparent p-4">
        <p className="text-[11px] uppercase tracking-widest text-[#64748b]" style={{ fontVariant: 'small-caps' }}>
          {t('nodes.refAddressLabel')}
        </p>
        <div className="mt-2 flex gap-2">
          <input
            readOnly
            value="https://rwa.protocol/ref/0x1234...5678"
            className="h-10 flex-1 rounded-xl border border-[#ffffff0d] bg-[#0d0d14] px-4 font-[family-name:var(--font-jetbrains-mono)] text-[12px] text-[#64748b] outline-none"
          />
          <button
            type="button"
            onClick={handleCopy}
            className="flex h-10 min-w-[40px] items-center justify-center rounded-full border border-[#ffffff1a] bg-transparent px-3 text-[12px] text-[#64748b] transition-colors hover:bg-[#13131e]"
            aria-label="Copy referral link"
          >
            {copied ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
            )}
          </button>
          <button
            type="button"
            className="flex h-10 items-center gap-1.5 rounded-full border border-[#ffffff1a] bg-transparent px-4 text-[12px] text-[#64748b] transition-colors hover:bg-[#13131e]"
          >
            {t('nodes.shareBtn')}
          </button>
        </div>
      </div>

      {/* Network tree SVG */}
      <div className="overflow-x-auto rounded-2xl border border-[#ffffff0d] bg-[#0d0d14] p-4">
        <svg
          width="600"
          height="220"
          viewBox="0 0 600 220"
          className="min-w-[600px]"
          style={{ overflow: 'visible' }}
        >
          <defs>
            <linearGradient id="lineGrad1" x1="300" y1="44" x2="110" y2="148" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00f5d4" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#1a1a2e" stopOpacity="0.6" />
            </linearGradient>
            <linearGradient id="lineGrad2" x1="300" y1="44" x2="300" y2="148" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00f5d4" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#1a1a2e" stopOpacity="0.6" />
            </linearGradient>
            <linearGradient id="lineGrad3" x1="300" y1="44" x2="490" y2="148" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00f5d4" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#1a1a2e" stopOpacity="0.6" />
            </linearGradient>
          </defs>

          {/* Connecting lines */}
          {children.map((child, i) => (
            <path
              key={child.id}
              d={`M ${root.x} ${root.y + 28} C ${root.x} ${(root.y + child.y) / 2} ${child.x} ${(root.y + child.y) / 2} ${child.x} ${child.y - 28}`}
              fill="none"
              stroke={`url(#lineGrad${i + 1})`}
              strokeWidth="1.5"
            />
          ))}

          {/* All nodes */}
          {TREE_NODES.map((node) => (
            <HexNode
              key={node.id}
              x={node.x}
              y={node.y}
              stroke={node.stroke}
              glow={node.glow}
              label={node.label}
              addr={node.addr}
              sub={node.sub}
              onHover={() => setHoveredId(node.id)}
              onLeave={() => setHoveredId(null)}
              isHovered={hoveredId === node.id}
              tMe={t('nodes.me')}
            />
          ))}

          {/* "+ 9 more" faded hint beside last child */}
          <text x="556" y="148" textAnchor="middle" dominantBaseline="middle" fontSize="10" fill="#334155" fontFamily="var(--font-space-grotesk), sans-serif">
            {t('nodes.more')}
          </text>
        </svg>
      </div>

      {/* View full network button */}
      <button
        type="button"
        className="mt-4 w-full rounded-full border border-[#ffffff1a] bg-transparent px-6 py-3 text-[13px] text-[#64748b] transition-colors hover:bg-[#13131e] hover:text-[#f1f5f9]"
      >
        {t('nodes.viewFull')}
      </button>
    </div>
  )
}
