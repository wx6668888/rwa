'use client'

import { useState, useRef, useEffect } from 'react'
import { Globe } from 'lucide-react'
import { useLocale } from '@/components/locale-provider'
import { localeOptions } from '@/lib/i18n'
import type { Locale } from '@/lib/i18n'

export function LanguageSwitcher() {
  const { locale, setLocale } = useLocale()
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  const current = localeOptions.find((o) => o.code === locale) || localeOptions[0]

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  function handleSelect(code: Locale) {
    setLocale(code)
    setOpen(false)
  }

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 rounded-full px-3 py-2 text-sm text-text-secondary transition-colors hover:bg-surface-2"
        aria-label="Switch language"
      >
        <Globe className="h-4 w-4" />
        <span className="hidden sm:inline">{current.name}</span>
      </button>

      {open && (
        <div className="absolute end-0 top-full z-50 mt-2 min-w-[180px] overflow-hidden rounded-xl border border-border-active bg-surface-2 shadow-2xl backdrop-blur-xl">
          {localeOptions.map((option) => (
            <button
              key={option.code}
              type="button"
              onClick={() => handleSelect(option.code)}
              className="flex h-10 w-full items-center justify-between px-4 text-sm transition-colors hover:bg-surface-3"
            >
              <span className={option.code === locale ? 'text-plasma-cyan' : 'text-text-primary'}>
                {option.flag} {option.name}
              </span>
              {option.code === locale && (
                <svg
                  className="h-4 w-4 text-plasma-cyan"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
