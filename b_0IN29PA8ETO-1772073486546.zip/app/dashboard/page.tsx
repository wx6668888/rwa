import { Navbar } from '@/components/navbar'
import { BackgroundEffects } from '@/components/background-effects'
import { WalletBar } from '@/components/dashboard/wallet-bar'
import { PortfolioCard } from '@/components/dashboard/portfolio-card'
import { EarningsCard } from '@/components/dashboard/earnings-card'
import { StatCards } from '@/components/dashboard/stat-cards'
import { ActivityTable } from '@/components/dashboard/activity-table'

export const metadata = {
  title: '仪表板 | RWA Protocol',
  description: '查看您的质押总额、收益和团队数据',
}

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-[#05050a] font-sans">
      <BackgroundEffects />
      <Navbar />
      <WalletBar />

      <main className="mx-auto max-w-7xl px-4 pb-[100px] pt-8 lg:px-8">
        {/* Row 1: Portfolio + Earnings — 2 equal columns on desktop */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <PortfolioCard />
          <EarningsCard />
        </div>

        {/* Row 2: 3 stat cards */}
        <div className="mt-4">
          <StatCards />
        </div>

        {/* Row 3: Activity table — full width */}
        <div className="mt-4">
          <ActivityTable />
        </div>
      </main>
    </div>
  )
}
