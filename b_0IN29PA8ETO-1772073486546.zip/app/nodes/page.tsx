import { Navbar } from '@/components/navbar'
import { BackgroundEffects } from '@/components/background-effects'
import { NodesPageClient } from '@/components/nodes/nodes-page-client'
import { ParticleField } from '@/components/nodes/particle-field'

export const metadata = {
  title: '节点等级 | RWA Protocol',
  description: '查看您的节点等级、奖励倍率和推荐网络',
}

export default function NodesPage() {
  return (
    <div className="relative min-h-screen bg-[#05050a]">
      <BackgroundEffects />
      <ParticleField />
      <Navbar />
      <NodesPageClient />
    </div>
  )
}
